package appointmentservice;

import java.util.Date;

import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
public class Appointment {

    private String id;
    private Date date;
    private String description;

    // Constructor accepts a Date object for validation
    public Appointment(String id, Date date, String description) {
        setId(id);
        setDate(date);
        setDescription(description);
    }

    public Appointment(Appointment other) {
		this(other.id, other.date, other.description);
	}

	// Validate and set the ID
    private void setId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("Id cannot be null!");
        } else if (id.length() > 10) {
            throw new IllegalArgumentException("Id cannot be more than 10 characters!");
        } else if (id.isEmpty()) {
            throw new IllegalArgumentException("Id cannot be empty!");
        }
        this.id = id;
    }
    
	// Validate and set the date
    public void setDate(Date date) {
        if (date == null) {
            throw new IllegalArgumentException("Date cannot be null!");
        } else if (date.before(new Date())) {
            throw new IllegalArgumentException("Date cannot be in the past!");
        }
        this.date = date;
    }
    
    // Validate and set the description
    public void setDescription(String description) {
		if(description == null) {
			throw new IllegalArgumentException("Description cannot be null!");
		}else if(description.length() > 50) {
			throw new IllegalArgumentException("Description cannot exceed 50 characters!");
		}
		this.description = description;
		
	}


    // Getters
    public String getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

	public String getDESCRIPTION() {
		
		return description;
	}
}
