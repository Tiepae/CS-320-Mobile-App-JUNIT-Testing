package appointmentservice;

import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
	
	private List<Appointment> appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<>();
	}

	public void add(Appointment newAppointment) {
	    for (Appointment appointment : appointments) {
	        if (appointment.getId().equals(newAppointment.getId())) {
	            throw new IllegalArgumentException(
	                "Cannot add appointment, duplicate ID found! " + newAppointment.getId()
	            );
	        }
	    }
	    appointments.add(newAppointment);
	}
	/**
	 * Get Appointment by ID
	 * Returns the appointment if found by the ID
	 * 
	 */
	public Appointment get(String id) {
	    for (Appointment appointment : appointments) {
	        if (appointment.getId().equals(id)) {
	            return appointment; // return the object directly
	        }
	    }
	    return null; // not found
	}
    // Delete appointment by ID
    public void delete(String id) {
        appointments.removeIf(a -> a.getId().equals(id));
    }

    // Edit appointment description and date by ID
    public void edit(String id, String newDescription, java.util.Date newDate) {
        Appointment appointment = get(id);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment with ID " + id + " not found!");
        }
        appointment.setDescription(newDescription);
        appointment.setDate(newDate);
    }
}
		

