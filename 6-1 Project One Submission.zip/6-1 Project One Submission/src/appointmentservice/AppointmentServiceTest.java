package appointmentservice;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
		
		private AppointmentService service;
	
		
		@BeforeEach
		public void setup() {
			service = new AppointmentService();
		}
		/////////////////////////////////
		/// ADD FUNCTIONALITY
		////////////////////////////////
		@Test
		public void testAdd_withNewElement_successfullAdds() {
		    // Create a date for tomorrow
		    Calendar cal = Calendar.getInstance();
		    cal.add(Calendar.DAY_OF_MONTH, 1); // tomorrow
		    Date testDate = cal.getTime();
			
			Appointment newAppointment = new Appointment("Test ID", testDate,"Test Description");
			service.add(newAppointment);
			Assertions.assertEquals(service.get(newAppointment.getId()), newAppointment);
		}
		/////////////////////////////////
		/// CHECK FOR DUPLICATES
		////////////////////////////////
	    @Test
	    public void testAdd_withDuplicateElement_throwsIllegalArgumentException() {
	        Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.DAY_OF_MONTH, 1);
	        Date testDate = cal.getTime();

	        Appointment newAppointment = new Appointment("Test ID", testDate, "Test Description");
	        service.add(newAppointment);
	        Assertions.assertNotNull(service.get(newAppointment.getId()));
	        // Check duplicate
	        Assertions.assertThrows(IllegalArgumentException.class, () -> service.add(newAppointment));
	    }
		//***************************************
		
	    //////////////////////////////////
	    /// DELETE FUNCTIONALITY
	    //////////////////////////////////
	    @Test
	    public void testDelete_removesAppointment() {
	        Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.DAY_OF_MONTH, 1);
	        Date testDate = cal.getTime();

	        Appointment newAppointment = new Appointment("DeleteID", testDate, "Delete Test");
	        service.add(newAppointment);

	        service.delete("DeleteID");
	        Assertions.assertNull(service.get("DeleteID"));
	    }

	    //////////////////////////////////
	    /// EDIT FUNCTIONALITY
	    //////////////////////////////////
	    @Test
	    public void testEdit_updatesAppointment() {
	        Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.DAY_OF_MONTH, 1);
	        Date originalDate = cal.getTime();

	        Appointment newAppointment = new Appointment("EditID", originalDate, "Original Description");
	        service.add(newAppointment);

	        // New date for editing
	        cal.add(Calendar.DAY_OF_MONTH, 2);
	        Date newDate = cal.getTime();
	        service.edit("EditID", "Updated Description", newDate);

	        Appointment edited = service.get("EditID");
	        Assertions.assertEquals("Updated Description", edited.getDESCRIPTION());
	        Assertions.assertEquals(newDate, edited.getDate());
	    }
	}

