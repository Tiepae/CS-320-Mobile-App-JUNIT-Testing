package appointmentservice;

import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
	
	final String VALID_DESCRIPTION = "A";
	final String VALID_ID = "1";
	// Implemented calendar date
	final Date VALID_DATE;
	{
	    Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DAY_OF_MONTH, 1); // 1 day in the past
	    VALID_DATE = cal.getTime();
	}
	
	//////////////////////////////////
	// TEST ID
	//////////////////////////////////
	
	@Test
	public void testId_withMinLengthValidId_IsSuccessful() {
		
		final String VALID_ID = "1";
		
		Appointment myTestAppointment = new Appointment(VALID_ID, VALID_DATE, VALID_DESCRIPTION);
		
		Assertions.assertEquals(VALID_ID, myTestAppointment.getId());
	}
	
	// TEST FOR NULL VALUE
	@Test
	public void testID_withNullValue_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, VALID_DATE, VALID_DESCRIPTION));
	}
	
	// TEST FOR MORE THAN 10 CHARACTERS
	@Test
	public void testID_withMoreThanTenCharacters_throwIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", VALID_DATE, VALID_DESCRIPTION));
	}
	
	// TEST IF ID HAS 10 CHARACTERS
	@Test
	public void testID_withTenCharacters_IsValid() {
	    final String VALID_ID_TEN = "1234567890";
	    Assertions.assertDoesNotThrow(() -> new Appointment(VALID_ID_TEN, VALID_DATE, VALID_DESCRIPTION));
	}
	
	// TEST IF ID IS EMPTY
	@Test
	public void testID_IdIsEmpty_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("", VALID_DATE, VALID_DESCRIPTION));
	}
	
	///	//////////////////////////////////
	// TEST DATE
	/////////////////////////////////////
	
	@Test
	public void testDate_withMinLengthValidId_IsSuccessful() {
		
		Appointment myTestAppointment = new Appointment(VALID_ID, VALID_DATE, VALID_DESCRIPTION);
		
		Assertions.assertEquals(VALID_DATE, myTestAppointment.getDate());
	}
	// TEST FOR NULL VALUE
	@Test
	public void testDATE_withNullValue_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(VALID_ID, null, VALID_DESCRIPTION));
	}
	// TEST BEFORE DATE
	public void testDATE_withPastDate_throwsIllegalArgumentException(){
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(VALID_ID, VALID_DATE, VALID_DESCRIPTION));
	}
	
	/////////////////////////////////////
	/// TEST DESCRIPTION
	////////////////////////////////////
	@Test
	public void testDescription_withValidValue_IsSuccessful() {
		
		Appointment myTestAppointment = new Appointment(VALID_ID, VALID_DATE, VALID_DESCRIPTION);
		
		Assertions.assertEquals(VALID_DESCRIPTION, myTestAppointment.getDESCRIPTION());
	}
	@Test
	public void testDescription_withNullValue_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(VALID_ID, VALID_DATE, null));
	}

}
