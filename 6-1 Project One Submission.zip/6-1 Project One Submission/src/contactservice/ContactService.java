// Manages Contact objects
/* Allows for:
 * adding
 * retrieving
 * updating
 * deleting
 */
package contactservice;

import java.util.ArrayList;
import java.util.List;

public class ContactService {

    private List<Contact> contacts;

    public ContactService() {
        contacts = new ArrayList<>();
    }

    public void add(Contact newContact) {
        for (Contact contact : contacts) {
            if (contact.getId().equals(newContact.getId())) {
                throw new IllegalArgumentException("Cannot add duplicate ID: " + newContact.getId());
            }
        }
        contacts.add(newContact);
    }

    public Contact get(String id) {
        for (Contact contact : contacts) {
            if (contact.getId().equals(id)) {
                return contact;
            }
        }
        return null;
    }

    public void delete(String id) {
        contacts.removeIf(contact -> contact.getId().equals(id));
    }

    public void updateFirstName(String id, String firstName) {
        Contact contact = get(id);
        if (contact != null) {
            contact.setFirstName(firstName);
        }
    }

    public void updateLastName(String id, String lastName) {
        Contact contact = get(id);
        if (contact != null) {
            contact.setLastName(lastName);
        }
    }

    public void updatePhone(String id, String phone) {
        Contact contact = get(id);
        if (contact != null) {
            contact.setPhone(phone);
        }
    }

    public void updateAddress(String id, String address) {
        Contact contact = get(id);
        if (contact != null) {
            contact.setAddress(address);
        }
    }
}
