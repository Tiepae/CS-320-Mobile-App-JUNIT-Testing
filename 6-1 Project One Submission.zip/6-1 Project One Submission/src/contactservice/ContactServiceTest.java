// Unit test for ContactService Class
package contactservice;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	/**
	 * Brought over the ContactTest Variables to allow lines 29 and 37 to function properly
	 */
	private final String VALID_ID = "1";
	private final String VALID_FIRST = "Jacob";
	private final String VALID_LAST = "McLemore";
	private final String VALID_PHONE = "1234567890";
	private final String VALID_ADDRESS = "1234 Main St";

    private ContactService service;

    @BeforeEach
    public void setup() {
        service = new ContactService();
    }

    // ADD
    @Test
    public void testAdd_withNewElement_successfullyAdds() {
        Contact newContact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        service.add(newContact);
        Assertions.assertEquals(service.get(newContact.getId()), newContact);
    }

    // checks for duplicates
    @Test
    public void testAdd_withDuplicateElement_throwsIllegalArgumentException() {
        Contact newContact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        service.add(newContact);
        Assertions.assertNotNull(service.get(newContact.getId()));
        Assertions.assertThrows(IllegalArgumentException.class, () -> service.add(newContact));
    }
}
