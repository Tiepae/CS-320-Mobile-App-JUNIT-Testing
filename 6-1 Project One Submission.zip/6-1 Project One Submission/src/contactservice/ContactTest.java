// Unit tests for contact classes
package contactservice;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {
    private final String VALID_ID = "1";
    private final String VALID_FIRST = "Jacob";
    private final String VALID_LAST = "McLemore";
    private final String VALID_PHONE = "1234567890";
    private final String VALID_ADDRESS = "1234 Main St";

    // Test ID attribute
    @Test
    public void testId_withValidId_IsSuccessful() {
        Contact myContact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        Assertions.assertEquals(VALID_ID, myContact.getId());
    }

    @Test
    public void testID_withNullValue_throwsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    @Test
    public void testID_withMoreThanMaxCharacters_throwsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678910", VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    // Test FIRSTNAME attribute
    @Test
    public void testFirstName_withValidValue_IsSuccessful() {
        Contact myContact = new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, VALID_ADDRESS);
        Assertions.assertEquals(VALID_FIRST, myContact.getFirstName());
    }

    @Test
    public void testFirstName_withNullValue_throwsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, null, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }
    // Tests to make sure its no longer than 10 characters
    @Test
    public void testFirstName_withExceedMaxLength_throwsIllegalArgumentException() {
        String tooLong = "ABCDEFGHIJK";
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, tooLong, VALID_LAST, VALID_PHONE, VALID_ADDRESS));
    }

    // Test LASTNAME attribute
    @Test
    public void testLastName_withNullValue_throwsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, VALID_FIRST, null, VALID_PHONE, VALID_ADDRESS));
    }

    // Test PHONE attribute
    @Test
    public void testPhone_withInvalidDigits_throwsIllegalArgumentException() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, VALID_FIRST, VALID_LAST, "12345", VALID_ADDRESS));
    }

    // Test ADDRESS attribute and makes sure its no longer than 30 characters
    @Test
    public void testAddress_withTooLong_throwsIllegalArgumentException() {
        String longAddress = "1234567890123456789012345678901";
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Contact(VALID_ID, VALID_FIRST, VALID_LAST, VALID_PHONE, longAddress));
    }
    // Creates a contact and creates a copy and verifies all the fields
    @Test
    public void testCopyConstructorAndGetters_ReturnsCorrectValues() {
        Contact original = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact copy = new Contact(original);

        Assertions.assertEquals(original.getId(), copy.getId());
        Assertions.assertEquals(original.getFirstName(), copy.getFirstName());
        Assertions.assertEquals(original.getLastName(), copy.getLastName());
        Assertions.assertEquals(original.getPhone(), copy.getPhone());
        Assertions.assertEquals(original.getAddress(), copy.getAddress());
    }
    
}