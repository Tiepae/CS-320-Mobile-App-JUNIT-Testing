package taskservice;

import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode
public class Task {
	
	private String id;
	private String name;
	private String description;

	public Task(String id, String name, String description) {
		setId(id);
		setName(name);
		setDescription(description);
	}
	public Task(Task other) {
		// TODO Auto-generated constructor stub
		this(other.id, other.name, other.description);
	}
	// Validation for Id
	// ------------------------------
	private void setId(String id) {
		if(id == null) {
			throw new IllegalArgumentException("Id cannot be null");
		} else if(id.length() > 10) {
			throw new IllegalArgumentException("Id cannot exceed 10 characters!");
		}else if (id.isEmpty()) {
			throw new IllegalArgumentException("Id cannot be empty");
		}
		this.id = id;
		
	}
    // Name Validation
    // ------------------------------
	public void setName(String name) {
		
		if(name == null) {
			throw new IllegalArgumentException("Name cannot be null");
		}else if(name.length() > 20) {
			throw new IllegalArgumentException("Name cannot exceed 20 characters!");
		}else if(name.isEmpty()) {
			throw new IllegalArgumentException("Name cannot be empty");
		}
		
		this.name = name;
		
	}
    // Description Validation
    // ------------------------------
    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description cannot be null");
        } else if (description.length() > 50) {
            throw new IllegalArgumentException("Description cannot exceed 50 characters!");
        } else if (description.isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty");
        }
        this.description = description;
    }


	public String getId() {
		
		return id;
	}
	public String getName() {
		
		return name;
	}
	public String getDescription() {
		
		return description;
	}

}
