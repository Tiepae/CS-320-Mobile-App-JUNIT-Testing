package taskservice;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	
    private List<Task> tasks;

    public TaskService() {
        tasks = new ArrayList<>();
    }

    public void add(Task newTask) {
        for (Task task : tasks) {
            if (task.getId().equals(newTask.getId())) {
                throw new IllegalArgumentException("Cannot add a duplicate task id: " + newTask.getId());
            }
        }
        tasks.add(newTask);
    }

    /**
     * Finds task by Id.
     * Returns the task if found, otherwise returns null.
     */
    public Task get(String id) {
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                return task;
            }
        }
        return null;
    }

    // DELETE tasks
    public void delete(String id) {
        Task toRemove = null;
        for (Task task : tasks) {
            if (task.getId().equals(id)) {
                toRemove = task;
                break;
            }
        }
        if (toRemove != null) {
            tasks.remove(toRemove);
        } else {
            throw new IllegalArgumentException("Task with ID " + id + " not found.");
        }
    }

    // EDIT tasks
    public void edit(String id, String newName, String newDescription) {
        Task toEdit = get(id);
        if (toEdit == null) {
            throw new IllegalArgumentException("Task with ID " + id + " not found.");
        }
        toEdit.setName(newName);
        toEdit.setDescription(newDescription);
    }
}
