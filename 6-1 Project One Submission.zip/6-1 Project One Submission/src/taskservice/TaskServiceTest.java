package taskservice;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

	private TaskService service;
	
	@BeforeEach
	public void setup() {
		service = new TaskService();
	}
	///////////////////////////////////////////////////////
	///ADD
	///////////////////////////////////////////////////////
	@Test
	public void TestAdd_withNewElement_successfullyAdds() {
		// Create a new Task
		// Add it to the service
		// Assert and check if it was added
		
		Task newTask = new Task("Test ID", "Test Name", "Test Description");
		
		service.add(newTask);
		
		Assertions.assertEquals(service.get(newTask.getId()), newTask);
	}
	// checks for Duplicates
	@Test
	public void testAdd_withDuplicateElement_throwsIllegalArgumentException() {
		Task newTask = new Task("Test ID", "Test Name", "Test Description");
		
		service.add(newTask);
		Assertions.assertNotNull(service.get(newTask.getId()));
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.add(newTask));
		
	}
	
	
	///////////////////////////////////////////////////////
	///DELETE
	///////////////////////////////////////////////////////
	@Test
	public void TestDelete_withExistingTask_successfullyDeletes() {
	    Task newTask = new Task("Test ID", "Test Name", "Test Description");
	    service.add(newTask);

	    service.delete("Test ID");

	    Assertions.assertNull(service.get("Test ID"));
	}

	@Test
	public void TestDelete_withNonExistingTask_throwsIllegalArgumentException() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> service.delete("Nonexistent ID"));
	}
	///////////////////////////////////////////////////////
	///EDIT
	///////////////////////////////////////////////////////
	@Test
	public void TestEdit_withExistingTask_successfullyEdits() {
    Task newTask = new Task("Test ID", "Test Name", "Test Description");
    service.add(newTask);

    service.edit("Test ID", "Updated Name", "Updated Description");

    Task editedTask = service.get("Test ID");
    Assertions.assertEquals("Updated Name", editedTask.getName());
    Assertions.assertEquals("Updated Description", editedTask.getDescription());
}

@Test
public void TestEdit_withNonExistingTask_throwsIllegalArgumentException() {
    Assertions.assertThrows(IllegalArgumentException.class, () -> service.edit("Nonexistent ID", "Name", "Description"));
}
}
