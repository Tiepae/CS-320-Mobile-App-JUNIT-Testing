package taskservice;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {
	private final String VALID_ID = "1";
	private final String VALID_NAME = "A";
	private final String VALID_NAME_MAX_LENGTH = "ABCDEFGHIJKLMNOPQRST";
	private final String TOO_LONG_NAME = "ABCDEFGHIJKLMNOPQRSTU";
	

	private final String VALID_DESCRIPTION = "Valid description";
	private final String VALID_DESCRIPTION_MAX_LENGTH = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWX"; // 50 chars
	private final String TOO_LONG_DESCRIPTION = "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXY"; // 51 chars

	// ------------------------------
	// ID TESTS
	// ------------------------------
	// Test ID
	@Test
	public void TaskTestId_withMinimumValidId_IsSuccessful() {
		Task myTestTask = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
		Assertions.assertEquals(VALID_ID, myTestTask.getId());
	}

	// Tests if Id is null and throws exception
	@Test
	public void TaskTestId_withNullValue_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, VALID_NAME, VALID_DESCRIPTION));	
	} 

	// Tests if there are more than 10 characters in the ID
	@Test
	public void TaskTestId_withMoreThanTenCharacters_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", VALID_NAME, VALID_DESCRIPTION));
	}

	// Test if there is a max of 10 characters in the ID
	@Test
	public void TastTestId_withTenCharacters_isValid() {
		final String VALID_ID_TEN = "1234567890";
		Task myTestTask = new Task(VALID_ID_TEN, VALID_NAME, VALID_DESCRIPTION);
		Assertions.assertEquals(VALID_ID_TEN, myTestTask.getId());
	}

	// Test if the ID string is empty...will be IllegalArgument
	@Test
	public void TaskTestId_withEmptyCharacters_throwsIllegalArgument() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("", VALID_NAME, VALID_DESCRIPTION));
	}

	// ------------------------------
	// NAME TESTS 
	// ------------------------------
	// Tests valid name (<= 20 chars)
	@Test
	public void TaskTestName_withMinimumValidId_IsSuccessful() {
		Task myTestTask = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
		Assertions.assertEquals(VALID_NAME, myTestTask.getName());
	}

	// Tests null name → throws exception
	@Test
	public void TaskTestName_withNullValue_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID, null, VALID_DESCRIPTION));
	}

	// Tests empty name → throws exception
	@Test
	public void TaskTestName_withEmptyCharacters_throwsIllegalArgument() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID,"", VALID_DESCRIPTION));
	}

	// Tests if long name (> 20 chars) → throws exception
	@Test
	public void TaskTestName_withMoreThanTwentyCharacters_throwsIllegalArgumentException() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID, TOO_LONG_NAME, VALID_DESCRIPTION));
	}

	// Tests if name is the MAX length
	@Test
	public void TaskTestName_withMaxTwentyCharacters_IsSuccessful() {
	    Task myTestTask = new Task(VALID_ID, VALID_NAME_MAX_LENGTH, VALID_DESCRIPTION);
	    Assertions.assertEquals(VALID_NAME_MAX_LENGTH, myTestTask.getName());
	}

	// ------------------------------
	// DESCRIPTION TESTS
	// ------------------------------
	// Tests valid description (<= 50 chars)
	@Test
	public void TaskTestDescription_withValidDescription_IsSuccessful() {
	    Task myTestTask = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION);
	    Assertions.assertEquals(VALID_DESCRIPTION, myTestTask.getDescription());
	}

	// Tests null description → throws exception
	@Test
	public void TaskTestDescription_withNullValue_throwsIllegalArgumentException() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID, VALID_NAME, null));
	}

	// Tests empty description → throws exception
	@Test
	public void TaskTestDescription_withEmptyCharacters_throwsIllegalArgument() {
	    Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID, VALID_NAME, ""));
	}

	// Tests too long description (> 50 chars) → throws exception
	@Test
	public void TaskTestDescription_withMoreThanFiftyCharacters_throwsIllegalArgumentException() {
		System.out.println(TOO_LONG_DESCRIPTION.length());
	    Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(VALID_ID, VALID_NAME, TOO_LONG_DESCRIPTION));
	}

	// Tests max description length (50 chars) → successful
	@Test
	public void TaskTestDescription_withMaxFiftyCharacters_IsSuccessful() {
	    Task myTestTask = new Task(VALID_ID, VALID_NAME, VALID_DESCRIPTION_MAX_LENGTH);
	    Assertions.assertEquals(VALID_DESCRIPTION_MAX_LENGTH, myTestTask.getDescription());
	}
}